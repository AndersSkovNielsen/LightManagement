BROADCAST_TO_PORT = 7000
import time
#from socket import *
from datetime import datetime
from sense_hat import SenseHat

sense = SenseHat()
accel_only = sense.get_accelerometer()
print("p: {pitch}, r: {roll}, y: {yaw}".format(**accel_only))
X = [255, 0, 0]  # Red
O = [255, 255, 255]  # White
image = [
X, X, X, X, X, X, X, X,
X, X, X, X, X, X, X, X,
X, X, X, X, X, X, X, X,
X, X, X, X, X, X, X, X,
X, X, X, X, X, X, X, X,
X, X, X, X, X, X, X, X,
X, X, X, X, X, X, X, X,
X, X, X, X, X, X, X, X
]
image2 = [
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, O, O, O, O, O
]



#s = socket(AF_INET, SOCK_DGRAM)
#s.bind(('', 14593))     # (ip, port)
# no explicit bind: will bind to default IP + random port
#s.setsockopt(SOL_SOCKET, SO_BROADCAST, 1)
data = "p: {pitch}, r: {roll}, y: {yaw}".format(**accel_only)
while True:
	print(data)
	#s.sendto(bytes(data, "UTF-8"), ('<broadcast>', BROADCAST_TO_PORT))
	data = "p: {pitch}, r: {roll}, y: {yaw}".format(**accel_only)
	time.sleep(0.1)
	sense.set_pixels(image2)
	
	time.sleep(0.3)
	accel_only = sense.get_accelerometer()
	data1 = "p: {pitch}, r: {roll}, y: {yaw}".format(**accel_only)
	if data1 != data:
	  sense.set_pixels(image)